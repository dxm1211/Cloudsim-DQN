from SimPy.Simulation import *

class Job(Process):
    def __init__(self, name, jobId, tasklist):
        Process.__init__(self, name=name)
        self.jobId = jobId
        self.tasklist = tasklist
        self.numtasks = len(tasklist)
