# Python modules
import sys
import math

# Simpy modules
from SimPy.Simulation import *

# CloudSim modules
from Scenario import *
from Scheduler import *
from SchedulingAlgos import *
from TaskGenerator import *
from Task import *
from AbstractResource import *
from CloudMachine import *

#Used in round robin scheduler
currentMachine = 0

inputFile = 'input'

totalTasks = 0

arguments = [
             ('--input', 'input file', 'input',),
             ('--conf', 'simulation conf file', 'scheduler.conf',)
             ]


def usage():
    string = 'USAGE:\n'
    global arguments
    for arg in arguments:
        string = string + ('Argument: %s (%s) - type: %s\n' % arg)
        
    string += '\nArguments are passed as follow: simgrid.py --argument-name value'
    return string

def parse_args():
    import sys
    if len(sys.argv) == 1:
        print((usage()))
        sys.exit()

    args = sys.argv[1:]
    if (len(args) < 4):
        print((usage()))
        sys.exit()
    
    scenario = None

    index = 0
    while index < len(args):
        if args[index] == '--conf':
            conf = args[index + 1]
            scenario = CloudSimScenario(conf)  #初始化scheduler.conf的参数
            index += 2 
        elif args[index] == '--input':
            global inputFile
            inputFile = args[index + 1]
            index += 2
        else:
            print(('Unknown option:' + str(args[index])))

    return scenario

def run(scenario, verbose=True):
    print("--------------- CloudSim ----------------")
    print("-----------------------------------------")
    initialize()
    scenario.init_objects()
    print("- Scenario initiated")

    print_initial_data(scenario)
    init_task_generators(scenario)

    scenario.printSep()
    print("- Running Simulation")
    simulate(until=scenario.sim_time)
    print("- Simulation complete")

    scenario.finish_objects()

    print_result(scenario)

    # scenario.executeMonitorPlots()

    return scenario, now()

def init_task_generators(scenario):
    global inputFile
    global totalTasks
    inputFile = open ('input', 'r')
    # Remove trailing endline characters
    temp = [x.strip () for x in inputFile.readlines ()]
    params = []
    for each in temp:
        y = each.split()
        # Remove commas from each input element except the last
        params = (list([x[:-1] for x in y[:-1]]) + [y[-1]])
        taskGenerator = JobGenerator (scenario, [params])  # Generate one TaskGenerator per input line
        totalTasks += int(taskGenerator.numTasks())
        activate (taskGenerator, taskGenerator.run(scenario.sim_time))

    scenario.remainingJobs = len(list(temp))

    scenario.printSep()
    print("- Job Generators created")
    print(("%s\t:\t %s" % ("Tasks to be generated", str(totalTasks))))


def print_initial_data(scenario):
    scenario.printSep()
    print("- Initial data:")
    # print(("%s\t:\t %s" % ("Execution mode",str(scenario.mode))))
    # print(("%s\t:\t %s" % ("Random seed",str(scenario.seed))))
    print(("%s\t:\t %s" % ("Scheduling algorithm",str(scenario.algoName))))
    # print(("%s\t:\t %d%%" % ("Acceptable waste",scenario.acceptableWaste)))
    # print(("%s\t:\t %s" % ("Started workers", str(scenario.initial_machines))))
    # print(("%s\t:\t %s" % ("Simulation time", str(scenario.sim_time))))

def print_result(scenario):
 
    allMachines = list(scenario.scheduler.activeMachines.values())+scenario.scheduler.destroyedMachines

    # Calculate total execution time,
    # wasted time, CPU time and total cost
    cpuTime = 0
    wastedTime = 0
    wastedSwStartup = 0
    wastedPart = 0
    totalCost = 0
    paidTime = 0
    for machine in allMachines:
        cpuTime += machine.getExecutionTime()
        # paidTime += machine.getPaidTime()
        # wastedTime += machine.getWastedTime()
        wastedSwStartup += machine.getWastedSwapAndStartup()
        # wastedPart += machine.getWastedPartialHours()
        # totalCost += machine.getExecutionCost()

    taskRTs = scenario.monitors["taskRT"]
    jobRTs = scenario.monitors["jobRT"]

    completedTasks = scenario.scheduler.completedTasks

    scenario.printSep()
    print("- Simulation results:")
    print(("%s\t:\t %d" % ("Total tasks", totalTasks)))
    print(("%s\t:\t %d (%.2f%%)" % ("Completed tasks", completedTasks, (float(completedTasks)/totalTasks)*100)))
    print(("%s\t:\t %.2fs" % ("Total execution time", now())))
    # print(("%s\t:\t %.2fs" % ("Total CPU time used",cpuTime)))
    # print(("%s\t:\t %.2fs" % ("Total CPU time paid", paidTime)))
    # print(("%s\t:\t %.2fs" % ("Total unused paid time",wastedTime)))
    # print(("-- %s\t:\t %.2fs (%.2f%%)" % ("Swap, idle and startup:",wastedSwStartup, (wastedSwStartup/wastedTime)*100)))
    # print(("-- %s\t:\t %.2fs (%.2f%%)" % ("Unused partial hour:",wastedPart, (wastedPart/wastedTime)*100)))
    # print(("%s\t:\t %.2f%%" % ("Percentage of waste", (wastedTime/paidTime)*100)))
    # print(("%s\t:\t $%.2f" % ("Total cost", totalCost)))
    print(("%s\t:\t %.2fs" % ("Average task response time", taskRTs.mean())))
    print(("%s\t:\t %.2fs" % ("Task response time std deviation", math.sqrt(taskRTs.var()))))
    print("%s\t:\t %ss" % ("Average job response time", str(jobRTs.mean())))
    print("%s\t:\t %s" % ("Job response time std deviation", str(math.sqrt(jobRTs.var()))))

def main():
    scenario = parse_args()
    return run(scenario)
    
if __name__ == '__main__':
     main()
