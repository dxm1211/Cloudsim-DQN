from SimPy.Simulation import *
from multiprocessing import Process

class Task(Process):
    def __init__ (self, name, tasksize, memory, jobId, numtasks, taskId):
        Process.__init__(self, name=name)
        self.size = tasksize
        self.usersize = tasksize   # 这里存的也是任务的大小，用来后面用户满意度的计算
        self.req_mem = memory
        self.jobId = jobId
        self.numtasks = numtasks
        self.taskId = taskId
        self.finished = False
        self.workerId = None
        self.startTime = None
