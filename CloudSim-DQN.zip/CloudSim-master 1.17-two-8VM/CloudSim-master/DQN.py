from __future__ import print_function
import tensorflow as tf
import random
import numpy as np
from collections import deque
import SchedulingAlgos
import os


NUMVM = 8 # 处理器个数，显然也是输入的大小
ACTIONS = NUMVM # 输出的个数
GAMMA = 0.9 # decay rate of past observations
EXPLORE = 3000. # frames over which to anneal epsilon
FINAL_EPSILON = 0.0001 # final value of epsilon
INITIAL_EPSILON = 0.5 # starting value of epsilon
BATCH = 50 # minibatch大小
MAXGEN = 50000 #训练多少次来保存结果5
REPLAY_MEMORY = 100
sche = 'sch'
TRAINTXT = 'train.txt'
EPSILON = 'epsilon.txt'
INPUT = 'qinput.txt'

## 接下来建立初始化神经网络权重的函数
# 从正态分布中输出随机值。 SHAPE表示一维的张量，stddv表示标准差
def weight_variable(shape):
    initial = tf.truncated_normal(shape, stddev = 0.01)
    return tf.Variable(initial)
# 常量的构成就是shape的形状
def bias_variable(shape):
    initial = tf.constant(0.01, shape = shape)
    return tf.Variable(initial)
# 初始化初始神经网络的函数
def createNetwork():
    w1 = weight_variable([NUMVM,50*NUMVM])  #8*400
    b1 = bias_variable([1,50*NUMVM])  # 1*400

    w2 = weight_variable([50*NUMVM,10*NUMVM])  # 400*80
    b2 = bias_variable([1,10*NUMVM])  # 1*80
    # 输出一个
    w3 = weight_variable([10*NUMVM,NUMVM])  # 80*8
    b3 = bias_variable([1,NUMVM]) # 1*8
    # 10个输入，最后得到10个输出
    # w4 = weight_variable([10 * NUMVM, NUMVM])
    # b4 = bias_variable([1, NUMVM])
    # 构建一个输入的tensor
    s = tf.placeholder("float", [None, NUMVM], name='input')  #输出

    wx_plus_b1 = tf.nn.relu(tf.add(tf.matmul(s, w1), b1, name='l1')) # 激活
    wx_plus_b2 = tf.nn.relu(tf.add(tf.matmul(wx_plus_b1, w2), b2, name='l2')) # 激活
    # wx_plus_b3 = tf.nn.relu(tf.add(tf.matmul(wx_plus_b2, w3), b3, name='l3'))
    wx_plus_b3 = tf.add(tf.matmul(wx_plus_b2, w3), b3, name='output') # 输出
    readout = wx_plus_b3  # nn输出的赋给 readout

    return s, readout # 返回状态s 以及 输出
# 训练网络
def trainNetwork(s, readout, sess):
    # 定义目标函数
    # with tf.name_scope('inputs'):
    a = tf.placeholder("float", [None, ACTIONS])
    # 标签，正确的东西，这个表示由max计算出来的Q值，作为目标值
    y = tf.placeholder("float", [None])
    #tf.summary.scalar('output', y)
    # 由神经网络输出的结果
    # 输出[[行求和],[]]的形式
    # (tf.multiply(readout, a)，点乘，*a之后就变成一行两列了，行数没确定
    # 输出由神经网络训练出来的 Q
    with tf.name_scope('output'):
         readout_action = tf.reduce_sum(tf.multiply(readout, a), reduction_indices=1)
    #tf.summary.scalar('output', readout_action)  # 可视化观看常量

    # 均方差，得到cost
    # 由算出来的Q-神经网络的Q
    with tf.name_scope('loss'):
         cost = tf.reduce_mean(tf.square(y - readout_action))  # loss
    merged = tf.summary.scalar('loss', cost)  # 可视化观看常量, cost的变化

    # 就是一个方法，用来求反向传播的值对权重的影响，这里没有使用SGD，而是使用的二次方梯度矫正
    # 给数据才能训练呀
    # 我们这里先使用的是拟-合的方法，后面我们编程softmax的方法
    with tf.name_scope('train'):
         # train_step = tf.train .AdamOptimizer(1e-6).minimize(cost)
         train_step = tf.train.GradientDescentOptimizer(0.1).minimize(cost)

    writer = tf.summary.FileWriter("C://my_tensorflow1", sess.graph)

    inputset = np.loadtxt(INPUT)
    s_t = inputset[0:NUMVM]   # input
    readout_t = readout.eval(feed_dict={s: [s_t]})[0]  # ？？？？
    # 动作的输出用的是hotindex，做才给1
    # a_t是根据ε 概率选择的Action
    a_t = np.zeros([ACTIONS])

    # eps = open("epsilon", 'r')
    # print(eps.read())
    if(os.path.getsize("epsilon") == 0):
        epsilon = 0.0
    else:
        # eps.close()
        eps = open("epsilon", 'r')
        epsi = float(eps.readline())
        epsilon = round(epsi, 8)  #  保留指定位数的小数
        eps.close()

    if random.random() <= epsilon:
        print("----------Random Action----------")
        action_index = random.randrange(ACTIONS)
        a_t[random.randrange(ACTIONS)] = 1
    else:
        # 否则，我们直接使用最大输出的值，argmax返回沿坐标轴的最大值
        # action_index = np.argmax(readout_t)
        action_index = np.argmax(readout_t)
        a_t[action_index] = 1

    # print("epsilon", epsilon)
    SchedulingAlgos.act = action_index
    # print(action_index)  # 输出动作

    # action = open("action",'a')
    # action.write(action_index + '\n')


    eps = open("epsilon", 'w')
    # eps.truncate()
    # scale down epsilon
    if epsilon > FINAL_EPSILON:   #  这里没起到作用，因为我们每次都开始新的一轮训练，epsilon应该永远都为初始化的值
        epsilon -= (INITIAL_EPSILON - FINAL_EPSILON) / EXPLORE   # 注意这里的EXPLORE会不会小了
        tem = str(epsilon)
        eps.write(tem)
        eps.close()
    else:
        eps.close()

    # Loss = "Loss.txt"

    D = deque()
    trainset = np.loadtxt(TRAINTXT)
    # for i in range(len(trainset)):
    # print(len(trainset))
    if(len(open("train.txt", 'rU').readlines()) == 1):
        s_t = trainset[0:NUMVM]
        a_t = trainset[NUMVM:2 * NUMVM]
        r_t = trainset[2 * NUMVM]
        s_t1 = trainset[2 * NUMVM + 1:3 * NUMVM + 1]
        terminal = trainset[3 * NUMVM + 1]
        D.append((s_t, a_t, r_t, s_t1, terminal))
    else:
        for i in range(0,len(trainset)):
           s_t = trainset[i,0:NUMVM]
           a_t = trainset[i,NUMVM:2 * NUMVM]
           r_t = trainset[i,2 * NUMVM]
           s_t1 = trainset[i,2 * NUMVM + 1:3 * NUMVM + 1]
           terminal = trainset[i,3 * NUMVM + 1]
           D.append((s_t, a_t, r_t, s_t1, terminal))

    if len(D) > REPLAY_MEMORY:
        D.popleft()

    if (len(D) < BATCH):
        minibatch = D
        s_j_batch = [d[0] for d in minibatch]
        a_batch = [d[1] for d in minibatch]
        r_batch = [d[2] for d in minibatch]
        s_j1_batch = [d[3] for d in minibatch]
    else:
        minibatch = random.sample(D,BATCH)
        s_j_batch = [d[0] for d in minibatch]
        a_batch = [d[1] for d in minibatch]
        r_batch = [d[2] for d in minibatch]
        s_j1_batch = [d[3] for d in minibatch]

    y_batch = []
    readout_j1_batch = readout.eval(feed_dict={s: s_j1_batch})

    for i in range(0,len(minibatch)):

        tempy = r_batch[i] + GAMMA * np.max(readout_j1_batch[i])
        # tempy /= 2   #
        y_batch.append(tempy)

    minibatch.clear()

        # perform gradient step
    train_step.run(feed_dict={
         y: y_batch,
         a: a_batch,
            # 这是神经网络的输入
         s: s_j_batch}
        )

    ff = open("Loss", 'a')
    Loss = sess.run(cost, feed_dict={
          y: y_batch,
          a: a_batch,
          s: s_j_batch})
    new_context = str(Loss) + '\n'
    ff.write(new_context)
    ff.close()

    checkpoint = tf.train.get_checkpoint_state("saved_networks")
    if (not (checkpoint and checkpoint.model_checkpoint_path)):
        t = 1
    else:
        t = len(open("Loss", 'rU').readlines())

    print("TIMESTEP", t, \
            "/ EPSILON", epsilon, "/ ACTION", action_index, "/ REWARD", r_t, \
            "/ Q_MAX %e" % np.max(readout_t))
    # print(readout_t)
    tf.reset_default_graph()
    result = sess.run(merged, feed_dict={   #  这里会报错，先注释
            y: y_batch,
            a: a_batch,
            s: s_j_batch})  # merged也是需要run的
    writer.add_summary(result, t)  # result是summary类型的，需要放入writer中，i步数（x轴）

def schedule():
    t = 1
    checkpoint = tf.train.get_checkpoint_state("saved_networks")
    if(not(checkpoint and checkpoint.model_checkpoint_path)):
        sess = tf.InteractiveSession()
        # 返回的图像张量，输出Q值，全连接值
        s, readout = createNetwork()
        saver = tf.train.Saver()
        sess.run(tf.global_variables_initializer())
        trainNetwork(s, readout, sess)
        # print(sess.run('Variable_5:0'))
        saver.save(sess, 'saved_networks/' + sche + '-dqn', global_step=t)
        sess.close()
    else:
        sess = tf.InteractiveSession()
        saver = tf.train.import_meta_graph('saved_networks/sch-dqn-1.meta')
        saver.restore(sess, checkpoint.model_checkpoint_path)
        # print(sess.run('Variable_5:0'))
        graph = tf.get_default_graph()
        s = graph.get_tensor_by_name("input:0")
        # print(s)
        readout = graph.get_tensor_by_name("output:0")
        # print(readout)
        trainNetwork(s, readout, sess)
        saver.save(sess, 'saved_networks/' + sche + '-dqn', global_step=t, write_meta_graph=False)
        sess.close()

def main():
     schedule()
# if __name__ == "__main__":
#     main()

# tensorboard --logdir="C://my_tensorflow"
#  http://nw1aqnwcfujugg1:6006/
# http://T-PC:6006