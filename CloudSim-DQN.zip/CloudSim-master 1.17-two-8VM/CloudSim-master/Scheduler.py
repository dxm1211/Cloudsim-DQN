from __future__ import print_function
import tensorflow as tf
import random
import numpy as np
from collections import deque
import os

from SimPy.Simulation import *
from AbstractResource import *
from CloudMachine import *
import math
from CloudSim import *


# ACTIONS = NUMVM # 输出的个数
GAMMA = 0.7 # decay rate of past observations
NUMVM = 8
EXPLORE = 10000. # frames over which to anneal epsilon
FINAL_EPSILON = 0.0001 # final value of epsilon
INITIAL_EPSILON = 0.5 # starting value of epsilon
BATCH = 50 # minibatch大小
REPLAY_MEMORY = 100
D = deque()
sche = 'sch'
TRAINTXT = 'train_one.txt'
EPSILON = 'epsilon.txt'
INPUT = 'qinput.txt'

class Scheduler(Process):
    def __init__(self, scenario, name="Scheduler"):
        Process.__init__(self, name=name)
        self.scenario = scenario

        # self.nextHour = 3600

        self.nextDestroy = 1000000000

        self.started = False

        self.completedTasks = 0

        self.jobid = 0
        self.genId = 0  # machine id
        self.activeMachines = {}
        self.destroyedMachines = []

        self.finTasksPerJob = {}
        self.numTasksPerJob = {}
        self.tasksPerMachine = {}  # machine上匹配执行的任务
        self.lefttaskspermachine = {}  # machine上当前还剩下多少分配给它的任务
        # self.lefttaskspermachine = []
        self.arrivetime = {}  # 任务的到达时间
        self.nonexecute = []  # 没有分配machine的任务
        self.starttimes = {}  # 任务的开始执行时间
        self.alltask = [] # 所有任务

        # [0] startTime
        # [1] remainingJobs
        self.jobInfos = {}
        self.jobTasks = {}

        self.maxRT = 0
        self.avgRT = [0, 0]
        self.minRT = 100000000
        self.maxRtPerWorker = {}
        self.avgRtPerWorker = {}
        self.minRtPerWorker = {}
        self.machinetimes = {}
        self.machinetimes1 = {}

        temp = scenario.addMonitor("activeTasksMon")
        scenario.addMonitorPlot("Running Tasks", temp)

        scenario.addMonitor("taskRT")
        scenario.addMonitor("jobRT")

        temp = scenario.addMonitor("activeNodesMon")
        scenario.addMonitorPlot("Running nodes", temp)

        temp = scenario.addMonitor("taskRTAvgMon")
        scenario.addMonitorPlot("Average task response time", temp)

        temp = scenario.addMonitor("jobRTAvgMon")
        scenario.addMonitorPlot("Average job response time", temp)

        temp = scenario.addMonitor("executionCostMon")
        scenario.addMonitorPlot("Cost of execution", temp)

        self.jobMeanTimes = {}  # TaskId > meanCompletionTime

        self.taskTimes = {}  # JobId > jobCompletionTime

        self.nextPoll = 0

        self.lastAvgTaskRT = 0
        self.lastAvgJobRT = 0

        self.rescheduled = False
        # self.hasFinished = False

        self.hasFinished = {}

        self.sati_sla = 0

        # init some parameters
        self.time_step = 0
        self.epsilon = INITIAL_EPSILON
        # self.state_dim = env.observation_space.shape[0]
        # self.action_dim = env.action_space.n
        # Init session
        self.sess = tf.InteractiveSession()
        self.createNetwork()
        self.saver = tf.train.Saver()
        self.create_training_method()
        self.sess.run(tf.global_variables_initializer())
        self.sess.graph.finalize()  # 冻结网络
        # 首先加载CheckPointState文件，然后采用saver.restore对已存在参数进行恢复。
        checkpoint = tf.train.get_checkpoint_state("saved_networks")
        # 如果关卡在模型路径中
        if checkpoint and checkpoint.model_checkpoint_path:  # ？？？
            # 载入模型
            # 继续上一个模型进行训练，ok
            self.saver.restore(self.sess, checkpoint.model_checkpoint_path)  # ？？？

    def weight_variable(self, shape):
        initial = tf.truncated_normal(shape, stddev=0.01)
        return tf.Variable(initial)

    # 常量的构成就是shape的形状
    def bias_variable(self, shape):
        initial = tf.constant(0.01, shape=shape)
        return tf.Variable(initial)

    # 初始化初始神经网络的函数
    def createNetwork(self):
        w1 = self.weight_variable([NUMVM, 50 * NUMVM])  # 8*400
        b1 = self.bias_variable([1, 50 * NUMVM])  # 1*400

        w2 = self.weight_variable([50 * NUMVM, 10 * NUMVM])  # 400*80
        b2 = self.bias_variable([1, 10 * NUMVM])  # 1*80
        # 输出一个
        w3 = self.weight_variable([10 * NUMVM, NUMVM])  # 80*8
        b3 = self.bias_variable([1, NUMVM])  # 1*8

        # 10个输入，最后得到10个输出
        # w4 = weight_variable([10 * NUMVM, NUMVM])
        # b4 = bias_variable([1, NUMVM])
        # 构建一个输入的tensor
        self.s = tf.placeholder("float", [None, NUMVM], name='input')  # 输出

        wx_plus_b1 = tf.nn.relu(tf.add(tf.matmul(self.s, w1), b1, name='l1'))  # 激活
        wx_plus_b2 = tf.nn.relu(tf.add(tf.matmul(wx_plus_b1, w2), b2, name='l2'))  # 激活
        # wx_plus_b3 = tf.nn.relu(tf.add(tf.matmul(wx_plus_b2, w3), b3, name='l3'))
        wx_plus_b3 = tf.add(tf.matmul(wx_plus_b2, w3), b3, name='output')  # 输出
        self.readout = wx_plus_b3  # nn输出的赋给 readout

    # return s, readout # 返回状态s 以及 输出

    def create_training_method(self):
        # with tf.name_scope('inputs'):
        self.a = tf.placeholder("float", [None, NUMVM])
        # 标签，正确的东西，这个表示由max计算出来的Q值，作为目标值
        self.y = tf.placeholder("float", [None])
        with tf.name_scope('output'):
            readout_action = tf.reduce_sum(tf.multiply(self.readout, self.a), reduction_indices=1)
        with tf.name_scope('loss'):
            self.cost = tf.reduce_mean(tf.square(self.y - readout_action))  # loss
        self.merged = tf.summary.scalar('loss', self.cost)
        with tf.name_scope('train'):
            # self.train_step = tf.train .AdamOptimizer(1e-6).minimize(self.cost)
            self.train_step = tf.train.GradientDescentOptimizer(0.1).minimize(self.cost)
        self.writer = tf.summary.FileWriter("C://my_tensorflow1", self.sess.graph)


    def myperceive(self):
        inputset = np.loadtxt(INPUT)
        s_t = inputset[0:NUMVM]  # input
        self.readout_t = self.readout.eval(feed_dict={self.s: [s_t]})[0]  # ？？？？
        if random.random() <= self.epsilon:
            # print("----------Random Action----------")
            self.action_index = random.randrange(NUMVM)
        else:
            # 否则，我们直接使用最大输出的值，argmax返回沿坐标轴的最大值
            # action_index = np.argmax(readout_t)
            self.action_index = np.argmax(self.readout_t)

        if self.epsilon > FINAL_EPSILON:  # 这里没起到作用，因为我们每次都开始新的一轮训练，epsilon应该永远都为初始化的值
            self.epsilon -= (INITIAL_EPSILON - FINAL_EPSILON) / EXPLORE  # 注意这里的EXPLORE会不会小了

        trainset = np.loadtxt(TRAINTXT)
        # if (len(open("train.txt", 'rU').readlines()) == 1):
        s_t = trainset[0:NUMVM]
        a_t = trainset[NUMVM:2 * NUMVM]
        r_t = trainset[2 * NUMVM]
        s_t1 = trainset[2 * NUMVM + 1:3 * NUMVM + 1]
        terminal = trainset[3 * NUMVM + 1]
        D.append((s_t, a_t, r_t, s_t1, terminal))

        if len(D) > REPLAY_MEMORY:
            D.popleft()

        # if len(self.D) > BATCH:   # 这里考虑要不要一开始就训练
        self.trainNetwork()

    # 训练网络
    def trainNetwork(self):
        # 定义目标函数
        self.time_step += 1
        # Step 1: obtain random minibatch from replay memory
        if (len(D) < BATCH):
            minibatch = D
            s_j_batch = [d[0] for d in minibatch]
            a_batch = [d[1] for d in minibatch]
            r_batch = [d[2] for d in minibatch]
            s_j1_batch = [d[3] for d in minibatch]
        else:
            minibatch = random.sample(D, BATCH)
            s_j_batch = [d[0] for d in minibatch]
            a_batch = [d[1] for d in minibatch]
            r_batch = [d[2] for d in minibatch]
            s_j1_batch = [d[3] for d in minibatch]

        # Step 2: calculate y
        y_batch = []
        readout_j1_batch = self.readout.eval(feed_dict={self.s: s_j1_batch})

        for i in range(0, len(minibatch)):
            tempy = r_batch[i] + GAMMA * np.max(readout_j1_batch[i])
            tempy /= 2
            y_batch.append(tempy)

        # perform gradient step
        self.train_step.run(feed_dict={
            self.y: y_batch,
            self.a: a_batch,
            # 这是神经网络的输入
            self.s: s_j_batch}
        )

        ff = open("Loss", 'a')
        Loss = self.sess.run(self.cost, feed_dict={
            self.y: y_batch,
            self.a: a_batch,
            self.s: s_j_batch})
        new_context = str(Loss) + '\n'
        ff.write(new_context)
        ff.close()

        # print("TIMESTEP", self.time_step, \
        #       "/ EPSILON", self.epsilon, "/ ACTION", self.action_index, \
        #       "/ Q_MAX %e" % np.max(self.readout_t))
        # print(readout_t)
        tf.reset_default_graph()
        result = self.sess.run(self.merged, feed_dict={  # 这里会报错，先注释
            self.y: y_batch,
            self.a: a_batch,
            self.s: s_j_batch})  # merged也是需要run的
        self.writer.add_summary(result, self.time_step)  # result是summary类型的，需要放入writer中，i步数（x轴）

        if(self.time_step % 1000 == 0):
            self.saver.save(self.sess, 'saved_networks/' + sche + '-dqn', global_step= self.time_step)


    def addTask(self, task):
        task.startTime = now()
        self.taskTimes[(task.jobId, task.taskId)] = -now()
        taskList = self.jobTasks.get(task.jobId)
        self.nonexecute.append(task)
        self.alltask.append(task)
        if (taskList == None):
            taskList = []
            jobInfo = [task.startTime, task.numtasks]
            self.jobInfos[task.jobId] = jobInfo

        taskList.append(task)
        self.jobTasks[task.jobId] = taskList

    machine_load = {}
    load = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    load1 = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]   # 存储上一次的负载
    cost = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]  # 成本
    percost = [1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5]  # 单价
    tasknum_m = [0,0,0,0,0,0,0,0] # 每个机器运行了多少任务

    file = open('result.txt', 'w')
    file2 = open('load.txt', 'w')
    file3 = open('reward', 'w')  # 两个目标的reward的值
    file4 = open('tworesult', 'w')  # 两个目标的state值
    file1 = open('train.txt', 'w')


    def taskFinished(self, task, machineId):
        self.hasFinished[task.jobId] = True
        finishTime = now()  # 在这个地方，该任务已经完成
        self.completedTasks += 1
        self.taskTimes[(task.jobId, task.taskId)] += finishTime
        taskTime = self.taskTimes[(task.jobId, task.taskId)]
        try:
            previousMean = self.jobMeanTimes[task.jobId]
            self.jobMeanTimes[task.jobId] = \
                [(previousMean[0] * previousMean[1] + taskTime) / (previousMean[1] + 1), previousMean[1] + 1]
        # print "Task mean of task %d was updated to %f" %(job.taskId, self.taskMeanTimes[job.taskId][0])

        except:
            self.jobMeanTimes[task.jobId] = [taskTime, 1]

        self.jobTasks[task.jobId].remove(task)
        tasksInMachine = self.tasksPerMachine.get(machineId)
        tasksInMachine.remove(task)
        self.lefttaskspermachine[machineId] = len(tasksInMachine)  # 做完一个任务就减去1

        # Calculate job service time
        if (self.machinetimes.get(machineId) == None):
            if (self.arrivetime[task.jobId] > self.scenario.sch_interval):
                starttime = task.startTime + self.arrivetime[task.jobId]
            else:
                starttime = task.startTime + self.scenario.sch_interval
        elif (self.arrivetime[task.jobId] > self.machinetimes.get(machineId)):
            starttime = self.arrivetime[task.jobId]
        else:
            starttime = self.machinetimes.get(machineId)
        self.starttimes[machineId] = starttime  # 将任务的开始时间存入,相对应于每个machine

        taskRT = finishTime - starttime
        self.scenario.monitors["taskRT"].observe(taskRT)
        print(("%d") % task.jobId + "-" + ("%d") % task.taskId + "\t" + ("%s %d") % ("machine", machineId) + "\t" + (
            "%s %.2fs") % ("start time", starttime) + "\t" + ("%s %.2fs") % ("finish time", finishTime) + "\t" + (
                  "%s %.2fs") % ("calculate time", taskRT))
        self.machinetimes[machineId] = (finishTime)  # machine做完最近一个任务的时间

        # 计算用户满意度
        usertime = task.usersize / CloudMachine.machine_speed[0] + self.arrivetime[task.jobId]  # deadline
        # 这里task的size变成0了，
        satisfaction = (usertime / finishTime) - 1
        # print(("%s %.2fs") % ("satisfaction", satisfaction))
        context = str(satisfaction) + ' '
        self.file2.write(context)  # 记录用户满意度

        self.load1[machineId] += taskRT  # 每做完一个任务，执行该任务的machine在当前时刻的负载
        # k = 0
        # totalcost = 0.0
        for load_result in self.load1:  # 查看经过实际运行之后，各个machine的load
            # totalcost += load_result * self.percost[k]
            context_load = str(load_result) + ' '
            self.file2.write(context_load)
            # k += 1
        # context_cost = str(totalcost) + ' '
        # self.file2.write(context_cost)
        self.file2.write("\n")


        # if (self.lefttaskspermachine.get(machineId) == 0):  # 假如该machine已经执行完分配给它的最后一个任务了
        #     self.machine_load[machineId] = finishTime - self.scenario.sch_interval
            # print(("%s %d") % ("machine", machineId) + "\t" + ("%s %.2fs") % ("load", self.machine_load[machineId]))

        self.avgRT = [(self.avgRT[0] * self.avgRT[1] + taskRT) / (self.avgRT[1] + 1), self.avgRT[1] + 1]
        self.maxRT = max([taskRT, self.maxRT])
        self.minRT = min([taskRT, self.minRT])
        workerRT = self.avgRtPerWorker[machineId]
        self.avgRtPerWorker[machineId] = [(workerRT[0] * workerRT[1] + taskRT) / (workerRT[1] + 1), workerRT[1] + 1]
        self.maxRtPerWorker[machineId] = max([self.maxRtPerWorker[machineId], taskRT])
        self.minRtPerWorker[machineId] = min([self.minRtPerWorker[machineId], taskRT])

        # print "avg RT: %s, max RT: %s, min RT: %s, worker %s min RT: %s, max RT %s, avg RT: %s)" % (self.avgRT, self.maxRT, self.minRT, machineId, self.minRtPerWorker[machineId], self.maxRtPerWorker[machineId], self.avgRtPerWorker[machineId])

        # Complete job in task info and check if
        # task is completed
        jobInfo = self.jobInfos[task.jobId]
        jobInfo[1] -= 1

        self.numTasksPerJob[task.jobId] -= 1
        self.finTasksPerJob[task.jobId] += 1

        # No jobs remaining - Task finished!
        if (jobInfo[1] == 0):
            # print(("Job %d is finished" %(task.jobId)))
            # Calculate task response time
            jobRT = finishTime - jobInfo[0]  # initialTime
            self.scenario.monitors["jobRT"].observe(jobRT)
            # print("%s %d" % ("job", task.jobId) + "\t" + "%s %.2fs" % ("totaltime", jobRT))

        allFinished = True
        for info in list(self.jobInfos.values()):
            if (info[1] > 0):
                allFinished = False
                break

        if (allFinished and self.scenario.remainingJobs == 0):
            stopSimulation()

    def dqn_schedule(self, workerList, jobs):
        # global currentMachine
        # orphanTasks = self.get_non_allocated_tasks(jobs)

        result = []
        for jobTasks in list(jobs.values()):
            for task in jobTasks:
                if (not task.finished and task.workerId == None):
                    result.append(task)
        allocations = []
        # global currentMachine
        # for task in orphanTasks:    # 在这里所有任务就已经和machine完成配对了
        if (result.__len__() > 0):
            task = result[0]
            if (task.jobId < 1):  # 前100个任务使用轮询算法
                allocations.append([workerList[random.randint(0, len(workerList) - 1)], task])
            else:
                self.myperceive()
                machine = workerList[self.action_index % len(workerList)]  # 这里替换成经过DQN训练之后选择的machine
                allocations.append([machine, result[0]])
        return allocations


    def run(self):

        # Create initial machines
        for m_id in range(self.scenario.initial_machines):
            # for m_id in range(self.scenario.initial_machines):
            self.createMachine(True, shutdown=self.scenario.sim_time)  # 这里创建了machine

        self.started = True

        while (self.started):  # 这里应该是指的整个模拟的开始，一直到结束

            if (int(now()) >= self.nextDestroy):
                nextNextDestroy = 10000000000
                for machine in list(self.activeMachines.values()):
                    thisDestroy = machine.getShutdownTime()
                    if (int(now()) >= thisDestroy):
                        self.destroyMachine(machine)
                    elif (thisDestroy < nextNextDestroy):
                        nextNextDestroy = thisDestroy
                self.nextDestroy = nextNextDestroy

            file_input = open('qinput.txt', 'w')
            # 写入执行动作前的状态，作为input
            maxload0 = max(self.load)
            minload0 = min(self.load)

            if(len(open("train.txt", 'rU').readlines()) > 0):
                for i in range(0,len(self.load)-1):
                    qinput = (self.load[i] - minload0) / (maxload0 - minload0)
                    new_context1 = str(qinput) + ' '
                    file_input.write(new_context1)
                    i += 1
                qinput1 = (self.load[len(self.load)-1] - minload0) / (maxload0 - minload0)
                new_context2 = str(qinput1)
                file_input.write(new_context2)
                file_input.flush()


            allocations = self.dqn_schedule(list(self.activeMachines.values()), self.jobTasks)
            # allocations = self.scenario.schedule_algorithm(list(self.activeMachines.values()), self.jobTasks, self)
            # allocations = self.OLB(list(self.activeMachines.values()), self.jobTasks)
            # 得到任务和machine的匹配
            self.allocate(allocations)

            if (int(now()) == self.nextPoll):
                self.scenario.monitors["activeTasksMon"].observe(sum([len(x) for x in list(self.jobTasks.values())]))
                self.scenario.monitors["activeNodesMon"].observe(len(self.activeMachines))

                # self.scenario.monitors ["taskRTAvgMon"].observe (self.getAvgTaskRT())
                # self.scenario.monitors ["jobRTAvgMon"].observe (self.getAvgJobRT())
                currentCost = 0
                allMachines = list(self.activeMachines.values()) + self.destroyedMachines

            yield hold, self, self.scenario.sch_interval  # sch_interval不能少，否则无法运行
            #  跳转到CloudMachine

    def allocate(self, allocations):
        # iterate over allocations generated by scheduling algorithm
        for machine_task in allocations:  # 这里是针对所有已经配对好的任务和machine
            machine = machine_task[0]
            task = machine_task[1]
            self.arrivetime[task.jobId] = now()  # 任务到达时间,每隔0.5秒来一个任务
            # print(self.arrivetime[task.jobId])

            self.nonexecute.remove(task)

            if (task.name == 'Task0-0'):  # 假如是第一个任务
                for i in range(self.scenario.initial_machines):
                    self.machinetimes1[i] = 0.5

            train_one = open('train_one.txt','w')
            maxload = max(self.load)
            minload = min(self.load)
            if (task.name == 'Task0-0'):
                for load_result in self.load:  # 将执行所选动作前的状态写入文件
                    # load_result1 = (load_result - minload) / (maxload - minload)  # 标准化
                    new_context = str(load_result) + '  '
                    self.file1.write(new_context)
                    train_one.write(new_context)
            else:
                self.file1.write('\n')
                for load_result in self.load:  # 将执行所选动作前的状态写入文件
                    load_result1 = (load_result - minload) / (maxload - minload)  # 标准化
                    new_context = str(load_result1) + '  '
                    self.file1.write(new_context)
                    train_one.write(new_context)

            action = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
            action[machine.id] = 1.0
            for act in action:  # 将动作序列写入文件
                new_context3 = str(act) + ' '
                # self.file.write(new_context3)
                self.file1.write(new_context3)
                train_one.write(new_context3)

            self.tasknum_m[machine.id] += 1

            if (self.machinetimes1[machine.id] > self.arrivetime[task.jobId]):
                eft = self.machinetimes1[machine.id] + task.usersize / CloudMachine.machine_speed[machine.id]
            else:
                eft = self.arrivetime[task.jobId] + task.usersize / CloudMachine.machine_speed[machine.id]

            user_time = self.arrivetime[task.jobId] + (task.usersize / CloudMachine.machine_speed[0])

            if (eft <= user_time):  # 假如满足SLA
                self.sati_sla += 1
                self.machinetimes1[machine.id] = eft  # 更新machine可开始执行任务的时间
                self.load[machine.id] += task.usersize / CloudMachine.machine_speed[machine.id]  # 更新load
            else:
                task.size = 0.0
                task.usersize = 0.0

            maxload1 = max(self.load)
            minload1 = min(self.load)
            totalload = 0
            for tem in self.load:
                totalload += tem
            averload = totalload / self.scenario.initial_machines  # 所有machine的平均负载
            temp = (self.load[machine.id] - minload1) / (maxload1 - minload1)
            aver = (averload - minload1) / (maxload1 - minload1)
            # load_reward = aver - temp

            if (eft <= user_time):
                if (self.load[machine.id] > averload):
                    load_reward = aver - temp
                else:
                    load_reward = 0.1
            else:
                    load_reward = -1.0

            # two_reward = 0.5 * sla_reward + 0.5 * load_reward

            new_context2 = str(load_reward) + ' '  # 将reward写入文件
            self.file1.write(new_context2)
            train_one.write(new_context2)

            for load_result2 in self.load:  # 将执行完所选的动作之后的状态写入文件
                load_result3 = (load_result2 - minload1) / (maxload1 - minload1)  # 标准化
                new_context = str(load_result3) + ' '
                self.file1.write(new_context)
                train_one.write(new_context)
                # print(load_result,cost_result)

            terminal = str(0.0)  # 判断是否终止
            # self.file.write(terminal + '\n')
            self.file1.write(terminal)
            train_one.write(terminal)
            self.file1.flush()
            train_one.flush()


            if(len(self.nonexecute) == 0):
                print("success tasks", self.sati_sla)
                print(self.tasknum_m)

            if (machine == None or task == None):
                # Invalid allocation
                self.log("Invalid allocation")
                continue

            # start job on machine
            # self.log("Adding task " + str(task.taskId) + " from job " + str(task.jobId) + " on machine " + str(machine.id))
            machine.addTask(task)

            tasksInMachine = self.tasksPerMachine[machine.id]
            tasksInMachine.append(task)

            if (self.numTasksPerJob.get(task.jobId) == None):
                self.numTasksPerJob[task.jobId] = 0
                self.finTasksPerJob[task.jobId] = 0
                self.hasFinished[task.jobId] = False

            self.numTasksPerJob[task.jobId] += 1



            # print(("%s  %d  %.2fs") % ("arrivetime", task.jobId, self.arrivetime[task.jobId]))

            # OLB算法 task放在最早可以开始执行任务的机器上做

    def OLB(self, workerList, jobs):
        result = []
        for jobTasks in list(jobs.values()):
            for task in jobTasks:
                if (not task.finished and task.workerId == None):
                    result.append(task)
        allocations = []
        # global currentMachine
        # for task in orphanTasks:    # 在这里所有任务就已经和machine完成配对了
        index = 0
        if (result.__len__() > 0):
            task = result[0]
            if (task.name == 'Task0-0'):  # 假如是第一个任务
                for i in range(self.scenario.initial_machines):
                    self.machinetimes1[i] = 0.5
            minavail = min(self.machinetimes1.values())  # 机器上的最早可开始执行时间
            for i in range(len(self.machinetimes1)):
                if (self.machinetimes1[i] == minavail):
                    index = i
                    break
            machine = workerList[index % len(workerList)]  # 这里替换成经过DQN训练之后选择的machine
            allocations.append([machine, task])
        return allocations

    def log(self, msg):
        print(("[%d] %s" % (now(), msg)))

    def guessEstimatedTime(self, taskId):
        remainingTasks = self.jobInfos[taskId][1]

        remainingTasks -= len(self.jobTasks[taskId])

        return remainingTasks

    def destroyMachine(self, machine):
        print(("[%d] Destroying machine %d" % (now(), self.genId)))
        machine.stop()
        # cancel(machine)
        del self.maxRtPerWorker[machine.id]
        del self.avgRtPerWorker[machine.id]
        del self.minRtPerWorker[machine.id]
        del self.tasksPerMachine[machine.id]
        del self.activeMachines[machine.id]
        self.destroyedMachines.append(machine)

    def createMachine(self, started=False, shutdown=3550):

        # this is a hack -- lalith
        if (shutdown == 3550):
            shutdown = self.scenario.sim_time

        shutdown += int(now())

        print(("[%d] Creating machine %d. Shutdown time: %d" % (now(), self.genId, shutdown)))

        if (shutdown < self.nextDestroy):
            self.nextDestroy = shutdown

        machine = CloudMachine(self.genId, self.scenario, shutdown, started)  # 初始化machine
        self.tasksPerMachine[machine.id] = []
        self.activeMachines[machine.id] = machine
        self.maxRtPerWorker[machine.id] = 0
        self.avgRtPerWorker[machine.id] = [0, 0]
        self.minRtPerWorker[machine.id] = 10000000
        self.genId += 1
        activate(machine, machine.start())  #
        return machine

    def stop(self):
        self.started = False


# tensorboard --logdir="C://my_tensorflow"