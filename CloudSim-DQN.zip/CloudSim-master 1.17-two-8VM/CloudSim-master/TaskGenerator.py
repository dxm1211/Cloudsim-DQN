from SimPy.Simulation import *
from Task import *
from Job import *
from CloudMachine import *

class JobGenerator(Process):

    def __init__(self, scenario, input_parameters):

        Process.__init__(self)
        self.scenario = scenario

        # Following are input parameters to the task generator.
        # Stores a list of input parameter tuples
        # self.task_parameters = list([tuple(int(x[0])) + tuple ([int(y) for y in x[1:]]) for x in input_parameters])
        # 因为第一个参数是str会无法识别，之前参数是mode “W”
        self.task_parameters = list([tuple ([int(y) for y in x[0:]]) for x in input_parameters])


        # XXX: Keep seeds modifiable later on!
        #self.cpuRandomObject = random.Random (1)
        #self.memRandomObject = random.Random (2)
        
        # This list of tasks is submitted to the scheduler
        self.joblist = []

    def jobId(self):
        return self.task_parameters[0][0]

    def numTasks(self):
        return self.task_parameters[0][1]   # task num

    def Instr(self):
        return self.task_parameters[0][3]

    def taskId(self):
        return self.task_parameters[0][5]

    def generate_jobs (self):

        for each in self.task_parameters:
            jobId, \
            numTasks, \
            rateOfTaskGeneration, \
            Instr, \
            Memory, \
            taskId = each
            # lowInstrBound, \
            # highInstrBound,\
            # lowMemBound, \
            # highMemBound = each

            # if (mode == 'W'):
                # Note that job-task correspondence is one-to-one
            webJobBucket = []

                # for taskId in range (0, numTasks):
                #     name = "Task%s-%s" % (jobId, taskId)
                #     reqInstr = int (Instr)
                #     reqMem = int (Memory)
                #     # JobId = 0, TaskId = taskId
                #     # jobInTask = Job (name, reqInstr, reqMem, taskId, numJobs, 0)
                #     taskInJob = Task(name, reqInstr, reqMem, jobId, numTasks, taskId)
                #     job = Job ("Job" + str(jobId), jobId, [taskInJob])
                #     webJobBucket.append(job)
            name = "Task%s-%s" % (jobId, taskId)
            reqInstr = int (Instr)
            reqMem = int (Memory)
                #     # JobId = 0, TaskId = taskId
                #     # jobInTask = Job (name, reqInstr, reqMem, taskId, numJobs, 0)
            taskInJob = Task(name, reqInstr, reqMem, jobId, numTasks, taskId)
            job = Job ("Job" + str(jobId), jobId, [taskInJob])
            webJobBucket.append(job)
            self.joblist.append (webJobBucket)

            # elif (mode == 'S'):
            #     # Create a set of tasks for the job
            #     tasklist = []
            #
            #     # for taskId in range (0, numTasks):
            #     #     name = "Task%s-%s" % (0, taskId)
            #     #     reqInstr = int (Instr)
            #     #     reqMem = int (Memory)
            #     #     tasklist.append (Task (name, reqInstr, reqMem, jobId, numTasks, taskId))
            #     name = "Task%s-%s" % (0, taskId)
            #     reqInstr = int (Instr)
            #     reqMem = int (Memory)
            #     tasklist.append (Task (name, reqInstr, reqMem, jobId, numTasks, taskId))
            #     job = Job ("Job" + str(taskId), taskId, tasklist)
            #     self.joblist.append ([job])

    def getNTasksFromBucket (self, i, rateOfTaskGeneration, N, tasksToBeAdded):
        '''
        Gets N jobs from the current Task Bucket.
        1) If there are at least rateOfJobGeneration number of jobs within the current
           task, then return a list of that many jobs.
        2) Else, extract as many jobs as possible from the current task, and extract the
           remainder number of jobs from the next task (recursion used).
        rateOfJobGeneration = 1
        '''
        if N == 0:
            return []
        try:
            for k in range (rateOfTaskGeneration):
                tasksToBeAdded.append (self.joblist[i][0].tasklist.pop(0))
        except IndexError: # Not enough jobs in the current task
            try:
                self.joblist[i].pop(0) # Move to next task
                tasksToBeAdded + self.getNTasksFromBucket(i, rateOfTaskGeneration, rateOfTaskGeneration - len(tasksToBeAdded), tasksToBeAdded)
            except IndexError: # Exhausted all tasks in the bucket. Move on.
                return tasksToBeAdded

        return tasksToBeAdded

    def run(self, finish):

        # Populate the task list
        self.generate_jobs()
         
        #activate (self.scenario.scheduler, self.scenario.scheduler.run())

        times = len (self.joblist)

        # For each task bucket
        for i in range(len(self.task_parameters)):
            # mode,\
            # startingTaskId,\
            # numJobs,\
            # rateOfJobGeneration,\
            # startingJobId,\
            # lowInstrBound,\
            # highInstrBound,\
            # lowMemBound,\
            # highMemBound
            jobId,\
            numTasks, \
            rateOfTaskGeneration, \
            Instr, \
            Memory, \
            taskId= self.task_parameters[i]
            # lowInstrBound, \
            # highInstrBound,\
            # lowMemBound, \
            # highMemBound = self.task_parameters[i]

            times = len(self.joblist[i])
            # For each task in a task bucket
            for x in range(times):

                while (numTasks):

                    tasksToBeAdded = self.getNTasksFromBucket (i, rateOfTaskGeneration, rateOfTaskGeneration, [])

                    for each in tasksToBeAdded:
                        self.scenario.scheduler.addTask(each)
                        numTasks -= 1

                    yield hold, self, 1
                    #print "Current time: " + str(now())

            self.scenario.remainingJobs -= 1
