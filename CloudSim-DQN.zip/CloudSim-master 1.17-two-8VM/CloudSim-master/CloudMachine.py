from SimPy.Simulation import *
from AbstractResource import *
from time import *
import math

class CloudMachine(Process):
    machine_mem = [1000,2000,3000,4000,5000,6000,7000,8000]
    machine_speed = [3000,8000,10000,12000,15000,20000,25000,30000]
    machine_cost = [1,2,3,4,5,6,7,8]
    machine_startup = [2,4,5,6,8,9,10,11]
    def __init__(self, mId, scenario, shutdownTime, started=False):
        Process.__init__(self, name="M-"+str(mId))
        self.id = mId
        self.tasks = []
        self.started = started
        self.startTime = 0
        self.stopTime = 0
        self.shutdownTime = shutdownTime
        self.memory = {}
        self.speed = self.machine_speed[mId]   # 速度
        self.availMem = self.machine_mem[mId]  # 内存
        self.percost = self.machine_cost[mId]  # 单价
        self.startup = self.machine_startup[mId]  # 启动时间
        self.scenario = scenario
        self.wasted = 0
        self.debug = False

    # def getPossibleTasks(self, avgTaskTime):
    #     leftTime = self.shutdownTime - int(now())
    #     return int(round(leftTime/avgTaskTime))

    def getShutdownTime(self):     # machine shutdown的时间
        return self.shutdownTime

    def getNumTasks(self):    # 任务数量
        return len(self.tasks)

    def addTask (self, task):
        task.workerId = self.id
        self.tasks.append(task)
        if (len(self.tasks) == 1):
            reactivate(self)

    def log(self, msg):
        if(self.debug):
          print((self.name + ">> " + msg))

    def getExecutionTime(self):
        if(self.stopTime == 0):
            return now() - self.startTime
        else:
            return self.stopTime - self.startTime

    # def getPaidTime(self):
    #     cpuTime = int(self.getExecutionTime())
    #     return cpuTime + 3600 - (cpuTime%3600)
    #
    # def getExecutionCost(self):
    #     paidTimeInHours = self.getPaidTime()/3600
    #     return paidTimeInHours * self.scenario.wn_cost

    def getWastedSwapAndStartup(self):
        return 0

    # def getWastedPartialHours(self):
    #     # return 3600 - (self.getExecutionTime()%3600)
    #     return 0
    #
    # def getWastedTime(self):
    #     return self.getWastedSwapAndStartup() + self.getWastedPartialHours()

    index1 = -1
    def start(self):
        if(not self.started):
          self.log("Starting machine.")
          self.startTime = now()
          # self.wasted += self.scenario.wn_startup
          self.started = True
          # Holds for startup time
          yield hold,self     #,self.scenario.wn_startup

        while(self.started):

            self.log("Tasks count: " + str(len(self.tasks)))

            if(len(self.tasks) > 0):

                # Selects next job in the list (round robin) 
                index = (self.index1+1)%len(self.tasks)
                currentTask = self.tasks[index]

                self.log("Selected task: " + str(currentTask.taskId))

                swapInsts = 0

                # if(currentTask.taskId not in self.memory):
                    # swapInsts = self.doSwapping(currentTask)

                neededInstr = currentTask.size #+ swapInsts
                # 根据machine计算执行时间
                #neededTime =  float(neededInstr)/self.scenario.wn_speed
                neededTime = float(neededInstr)/self.machine_speed[self.id]

                quantum = min(self.scenario.wn_quantum,neededTime)

                # Executes selected job
                # instructions for a quantum
                yield hold,self,quantum     #  跳到Simulation.py   quantum其实是delay的值

                self.log("Quantum: " + str(quantum) + "s")

                # 下面这块别删，否则任务执行时间就不对了
                #executed = (int)(quantum*self.scenario.wn_speed) - swapInsts
                executed = (int)(quantum*self.machine_speed[self.id]) - swapInsts
                if(executed > 0):
                    currentTask.size -= executed

                self.log("Task " + str(currentTask.taskId) + " size is: " + str(currentTask.size) + "insts.")

                if(currentTask.size <= 0):
                    self.finishTask(currentTask)
            else:
                self.wasted += self.scenario.wn_quantum
                yield hold,self,self.scenario.wn_quantum

        print(("[%.2f] Machine %d left loop" % (now(), self.id)))

    def stop(self):
        self.started = False
        self.stopTime = now()
        for task in self.tasks:
            task.workerId = None
        return self.tasks

    def isFinished(self):
        return not self.started

    def finishTask(self, task):
        self.log("Finishing task " + str(task.taskId))
        self.tasks.remove(task)
        task.finished = True
        # self.swapOut(task.taskId)
        self.scenario.scheduler.taskFinished(task, self.id)    # 一个任务结束
        # print("%s %.2fs" %("finish time" , now()))
    
    def swapOut(self, taskId):
        mem = self.memory.pop(taskId)

        self.availMem += mem
        self.log("Swapped out " + str(mem) + "MB from task " + str(taskId) + ".")
        self.log("Available memory: " + str(self.availMem))

        return mem

    def swapIn(self, taskId, taskMem):
        self.memory[taskId] = taskMem
        self.availMem -= taskMem
        self.log("Swapped in " + str(taskMem) + "MB for task " + str(taskId) + ".")
        self.log("Available memory: " + str(self.availMem))
        return taskMem

    def doSwapping(self, task):
        swapOut = 0
        swapIn = 0

        # Not enough space in memory - SWAP OUT
        if(self.availMem < task.req_mem):
            neededMem = task.req_mem - self.availMem
            # Swaps out jobs until it swapped out
            # the needed memory
            for memTask in list(self.memory.items()):
              swapOut += self.swapOut(memTask[0])
              if(swapOut >= neededMem):
                break

        # Memory has enough space - SWAP IN
        swapIn = self.swapIn(task.taskId,task.req_mem)

        swapInsts = max(0,int(self.scenario.wn_swap*max(swapOut,swapIn)))

        self.wasted += swapInsts/self.scenario.wn_speed

        return swapInsts
